import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { UserDetailComponent } from '../component/user-detail/user-detail.component';
import { SignInComponent } from '../component/sign-in/sign-in.component';

const routes: Routes = [
  { path: 'user-detail', component: UserDetailComponent },
  { path: 'sign-in', component: SignInComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    CommonModule
  ],
  declarations: [],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
