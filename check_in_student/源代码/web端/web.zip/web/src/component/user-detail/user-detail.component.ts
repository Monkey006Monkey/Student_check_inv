import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { HttpServiceProvider } from '../../providers/http-service';

import { SchoolDepartment } from '../../shared/SchoolDepartment';
import { SCHOOLDEPARTMENT } from '../../shared/mock.school';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
  info: any;
  user_school: number;
  detail: any;
  school_department: SchoolDepartment[] = SCHOOLDEPARTMENT;
  select_school_department: string[];
  constructor(private title: Title,
              private http_service: HttpServiceProvider) {
    this.select_school_department = [];
    this.detail = {
      id: '',
      name: '',
      gender: '',
      school: undefined,
      department: ''
    };
    const param = {
      action: 'get',
      account: this.info.account,
      identity: this.info.identity
    };
    this.http_service.http_post('edit_detail', param)
      .then((data) => {
        this.detail = data;
      });
    this.select_school_department = SCHOOLDEPARTMENT[this.user_school].department;
  }

  ngOnInit() {
    this.title.setTitle('个人信息修改');
  }
  setSelectSchool() {
    const id = this.detail.school;
    this.select_school_department = SCHOOLDEPARTMENT[id].department;
  }
  commit() {
    if (this.detail.id !== '' &&
      this.detail.name !== '' &&
      this.detail.gender !== '' &&
      this.detail.school !== undefined &&
      this.detail.department !== '') {
      const param = {
        action: 'commit',
        account: this.info.account,
        identity: this.info.identity,
        detail: this.detail
      };
      this.http_service.http_post('edit_detail', param)
        .then((data) => {
          if (data.answer === true) {
            this.toastCtrl.create({
              message: '修改成功！',
              duration: 3000
            }).present();
            const login_config = {
              is_login: true,
              user_info: {
                account: this.info.account,
                name: this.detail.name,
                identity: this.info.identity,
                school: this.detail.school,
                department: this.detail.department
              }
            };
            this.storage.set('Login', login_config);
            this.navCtrl.pop();
          } else {
            this.toastCtrl.create({
              message: '修改失败！',
              duration: 3000
            }).present();
          }
        });
    }
  }
}
