import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { Seat } from '../../shared/seat';
import { SeatDetail } from '../../shared/seat-detail';

import { SEAT } from '../../shared/mock.seat';
import {HttpServiceProvider} from '../../providers/http-service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
  bool_send: boolean;
  course: any;
  show: number;
  seat: Seat = {
    row: undefined,
    col: undefined,
    detail: []
  };
  select_seat = {
    row: 1,
    col: 1
  };
  row = [];
  col = [];
  constructor(private title: Title,
              private http_service: HttpServiceProvider) {
    this.bool_send = false;
    this.show = -1;
    this.course = this.navParams.get('course');
    console.log(this.course);
    for (let i = 1; i <= this.course.c_rows; i++) {
      this.row.push(i);
    }
    for (let i = 1; i <= this.course.c_columns; i++) {
      this.col.push(i);
    }
    const param = {
      action: 'check',
      c_id: this.course.c_id
    };
    this.http_service.http_post('sign_in', param)
      .then((data) => {
        if (data.answer === false) {
          this.show = 0;
        } else {
          let p2 = {
            action: 'check_sign',
            c_id: this.course.c_id,
            s_account: this.storage.get('Login', {}).user_info.account
          };
          this.http_service.http_post('sign_in', p2)
            .then((data) => {
              if (data.answer === false) {
                this.show = 2;
              } else {
                this.show = 1;
              }
            });
        }
      });
  }

  ngOnInit() {
    this.title.setTitle('个人信息修改');
  }
  sign_in() {
    const param = {
      action: 'sign_in',
      c_id: this.course.c_id,
      position: (this.select_seat.row - 1) * this.course.c_columns + this.select_seat.col * 1,
      s_account: this.storage.get('Login', {}).user_info.account
    };
    console.log(param.position);
    this.bool_send = true;
    this.http_service.http_post('sign_in', param)
      .then((data) => {
        if (data.answer === true) {
          this.alertCtrl.create({
            message: '签到成功！',
            buttons: ['确定']
          }).present();
          this.bool_send = false;
          this.show = 2;
        } else {
          this.alertCtrl.create({
            title: '该位置不可用！',
            message: '该位置已被其他人签到，请确认您现在所在的位置！',
            buttons: ['确定']
          }).present();
          this.bool_send = false;
        }
      });
  }
}
