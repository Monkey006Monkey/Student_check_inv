import { SchoolDepartment } from "./SchoolDepartment";

export const SCHOOLDEPARTMENT: SchoolDepartment[] = [
  {
    id: 0,
    name: '福州大学',
    department: [
      '数学与计算机科学学院',
      '电气工程学院',
      '法学院',
      '外国语学院',
      '建筑学院',
      '土木工程学院'
    ]
  },
  {
    id: 1,
    name: '福建师范大学',
    department: [
      '体育学院',
      '传播学院',
      '公共管理学院',
      '旅游学院'
    ]
  },
  {
    id: 2,
    name: '福建工程学院',
    department: [
      '软件学院',
      '信息学院',
      '材料科学与工程学院',
      '建筑与城乡规划学院',
      '人文学院',
      '法学院'
    ]
  }
];
