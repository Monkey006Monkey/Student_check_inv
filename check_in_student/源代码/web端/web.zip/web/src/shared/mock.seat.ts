import { Seat } from "./seat";

export const SEAT: Seat = {
  row: 1,
  col: 1,
  detail: []
};
