export class SeatDetail {
  row: number;
  col: number;
  avail: boolean;
}
