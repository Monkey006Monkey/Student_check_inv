export class SelectCourseInfo {
  s_account: string;
  s_name: string;
  s_gender: string;
  s_school: number;
  s_department: string;
  t_account: string;
  t_name: number;
  c_id: string;
  c_name: string;
  c_start_week: number;
  c_end_week: number;
  c_date: number;
  c_time: string;
  c_location: string;
  c_rows: number;
  c_columns: number;
  sign_count: number;
}
