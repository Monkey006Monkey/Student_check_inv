import { SeatDetail } from "./SeatDetail";

export class Seat {
  row: number;
  col: number;
  detail: SeatDetail[];
}
