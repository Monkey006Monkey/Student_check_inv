export class SeatDetail {
  row: number;
  col: number;
  avail: boolean;
  s_account: string;
}
