export class StudentDetail {
  account: string;
  password: string;
  identity: string;
  id: string;
  name: string;
  gender: string;
  school: number;
  department: string;
  photo: string;
}
