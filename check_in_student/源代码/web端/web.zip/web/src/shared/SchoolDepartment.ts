export class SchoolDepartment {
  id: number;
  name: string;
  department: string[]
}
