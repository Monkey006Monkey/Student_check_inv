import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';

/*
  Generated class for the HttpServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class HttpServiceProvider {
  constructor(private http: HttpClient) {
  }

  combine_url(target: string) {
    return 'http://acm.fzu.edu.cn/gc' + target + '.php';
  }
  /*jsonp_get(target: string, params: URLSearchParams): Promise<any> {
    let url = 'http://59.77.134.176/' + target + '.php';
    params.set('callback', '__ng_jsonp__.__req' + HttpServiceProvider.times + '.finished');
    console.log(params.toString());
    HttpServiceProvider.times++;
    return new Promise((resolve) => {
      this.jsonp.get(url, {search: params.toString()})
        .map(res => res.json())
        .subscribe((data) => {
          console.log(data);
          resolve(data);
        });
    });
  }*/
  http_get(target: string, params: HttpParams): Promise<any> {
    const url = this.combine_url(target);
    return new Promise((resolve) => {
      this.http.get(url, {
        params: params
      })
        .subscribe((data) => {
          console.log(data);
          resolve(data);
        });
    });
  }
  http_post(target: string, params: any): Promise<any> {
    const url = this.combine_url(target);
    console.log(url);
    return new Promise((resolve) => {
      this.http.post(url, JSON.stringify(params))
        .subscribe((data) => {
          console.log(data);
          resolve(data);
        });
    });
  }
}
