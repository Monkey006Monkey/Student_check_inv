import { Component } from '@angular/core';
import { AlertController, Events, IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { RegisterPage } from "../register/register";

import { HttpServiceProvider } from "../../providers/http-service/http-service";

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  login_info = {
    account: '',
    password: '',
    identity: ''
  };
  selectOptions: any;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private toastCtrl: ToastController,
              private alertCtrl: AlertController,
              private events: Events,
              private http_service: HttpServiceProvider) {
    this.selectOptions = {
      title: '选择您的身份',
      mode: 'md'
    };
  }

  ionViewDidLoad() {
  }
  Login() {
    if (this.login_info.account=="" || this.login_info.password=="" || this.login_info.identity=="") {
      this.toastCtrl.create({
        message: '登录信息填写不完整',
        duration: 2000
      }).present();
    }
    else {
      this.http_service.http_post('login', this.login_info)
        .then((data) => {
          if (data.answer == true) {
            this.events.publish('Login', data.detail);
          } else {
            this.alertCtrl.create({
              title: '登录失败！',
              message: '用户名、密码或身份错误',
              buttons: ['确定']
            }).present();
          }
        });
    }
  }
  toRegister() {
    this.navCtrl.push(RegisterPage);
  }
}
