import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { LocalStorageProvider } from "../../providers/local-storage/local-storage";
import { HttpServiceProvider } from "../../providers/http-service/http-service";

import { SelectCourseInfo } from "../../shared/SelectCourseInfo";

/**
 * Generated class for the HistoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-history',
  templateUrl: 'history.html',
})
export class HistoryPage {
  sign_info: SelectCourseInfo[] = [];
  s_account: string;
  show: number;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private storage: LocalStorageProvider,
              private http_service:　HttpServiceProvider) {
    this.show = -1;
    this.s_account = this.storage.get('Login', {}).user_info.account;
    let param = {
      action: 'student',
      s_account: this.s_account
    };
    this.http_service.http_post('history', param)
      .then((data) => {
        this.sign_info = data;
        if (data.length == 0) {
          this.show = 0;
        } else {
          this.show = 1;
        }
      });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad HistoryPage');
  }
}
