import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TeacherCheckPage } from './teacher-check';

@NgModule({
  declarations: [
    TeacherCheckPage,
  ],
  imports: [
    IonicPageModule.forChild(TeacherCheckPage),
  ],
})
export class TeacherCheckPageModule {}
