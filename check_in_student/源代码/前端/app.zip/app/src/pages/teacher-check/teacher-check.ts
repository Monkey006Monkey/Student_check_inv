import { Component } from '@angular/core';
import { AlertController, IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { HttpServiceProvider } from "../../providers/http-service/http-service";

import { Seat } from "../../shared/Seat";
import { SeatDetail } from "../../shared/SeatDetail";
import {ShowDetailPage} from "../show-detail/show-detail";

/**
 * Generated class for the TeacherCheckPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-teacher-check',
  templateUrl: 'teacher-check.html',
})
export class TeacherCheckPage {
  course: any;
  show: number;
  seat: Seat = {
    row: undefined,
    col: undefined,
    detail: []
  };
  row = [];
  col = [];
  bool_send: boolean;
  sign_number: number;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private http_service: HttpServiceProvider,
              private alertCtrl: AlertController,
              private toastCtrl: ToastController) {
    this.bool_send = false;
    this.show = -1;
    this.course = this.navParams.get('course');
    for (let i = 1; i <= this.course.c_rows; i++) {
      this.row.push(i);
    }
    for (let i = 1; i <= this.course.c_columns; i++) {
      this.col.push(i);
    }
    this.check();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignInPage');
  }
  start_sign_in() {
    this.seat = {
      row: undefined,
      col: undefined,
      detail: []
    };
    this.seat.row = this.course.c_rows;
    this.seat.col = this.course.c_columns;
    let a: SeatDetail = {
      row: 0,
      col: 0,
      avail: false,
      s_account: ''
    };
    this.seat.detail.push(a);
    for (let i = 1; i <= this.course.c_rows; i++) {
      for (let j = 1; j <= this.course.c_columns; j++) {
        let d: SeatDetail = {
          row: i,
          col: j,
          avail: true,
          s_account: ''
        };
        this.seat.detail.push(d);
      }
    }
    let param = {
      action: 'start_sign_in',
      c_id: this.course.c_id,
      seat: this.seat
    };
    this.bool_send = true;
    this.http_service.http_post('sign_in', param)
      .then((data) => {
        if (data.answer == true) {
          this.toastCtrl.create({
            message: '开启签到成功',
            duration: 3000
          }).present();
          this.show = 1;
          this.sign_number = 0;
          this.bool_send = false;
        } else {

          this.toastCtrl.create({
            message: '开启签到失败',
            duration: 2000
          }).present();
          this.bool_send = false;
        }
      });
  }
  end_sign_in() {
    this.alertCtrl.create({
      message: '真的要结束签到吗？',
      buttons: [
        {
          text: '确认',
          handler: () => {
            let param = {
              action: 'end_sign_in',
              c_id: this.course.c_id
            };
            this.http_service.http_post('sign_in', param)
              .then((data) => {
                if (data.answer == true) {
                  this.toastCtrl.create({
                    message: '结束签到成功',
                    duration: 3000
                  }).present();
                  this.show = 0;
                  this.bool_send = false;
                } else {
                  this.toastCtrl.create({
                    message: '结束签到失败',
                    duration: 2000
                  }).present();
                  this.bool_send = false;
                }
              });
          }
        },
        {
          text: '取消'
        }
      ]
    }).present();
  }
  check() {
    this.bool_send = true;
    let param = {
      action: 'check',
      c_id: this.course.c_id
    };
    this.http_service.http_post('sign_in', param)
      .then((data) => {
        if (data.answer == false) {
          this.show = 0;
          this.bool_send = false;
        } else {
          this.show = 1;
          this.seat = data.seat;
          this.sign_number = this.cal_sign_number();
          this.bool_send = false;
          console.log(data.seat);
        }
      });
  }
  cal_sign_number(): number{
    let ret = -1;
    this.seat.detail.forEach((value) => {
      if (value.avail == false) {
        ret++;
      }
    });
    return ret;
  }
  show_detail(r, c) {
    if (this.seat.detail[(r - 1) * this.seat.col + c].avail == true) return ;
    let param = {
      action: 'show_detail',
      s_account: this.seat.detail[(r - 1) * this.seat.col + c].s_account
    };
    this.bool_send = true;
    this.http_service.http_post('sign_in', param)
      .then((data) => {
        this.navCtrl.push(ShowDetailPage, {s_info: data});
        this.bool_send = false;
      });
  }
}
