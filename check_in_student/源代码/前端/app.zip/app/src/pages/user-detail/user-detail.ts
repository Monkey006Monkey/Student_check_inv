import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { LocalStorageProvider } from "../../providers/local-storage/local-storage";
import { HttpServiceProvider } from "../../providers/http-service/http-service";

import { SchoolDepartment } from "../../shared/SchoolDepartment";

import { SCHOOLDEPARTMENT } from "../../shared/mock.school";

/**
 * Generated class for the UserDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-user-detail',
  templateUrl: 'user-detail.html',
})
export class UserDetailPage {
  bool_send: boolean;
  type: string;
  info: any;
  user_school: number;
  detail: any;
  school_department: SchoolDepartment[];
  select_school_department: string[];
  password_old: string;
  password_new: string;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private storage: LocalStorageProvider,
              private http_service: HttpServiceProvider,
              private toastCtrl: ToastController) {
    this.type = this.navParams.get('type');
    this.bool_send = false;
    this.select_school_department = [];
    this.school_department = SCHOOLDEPARTMENT;
    this.info = this.storage.get('Login', {}).user_info;
    this.user_school = this.storage.get('Login', {}).user_info.school;
    this.detail = {
      id: '',
      name: '',
      gender: '',
      school: undefined,
      department: ''
    };
    let param = {
      action: 'get',
      account: this.info.account,
      identity: this.info.identity
    };
    this.http_service.http_post('edit_detail', param)
      .then((data) => {
        this.detail = data;
      });
    this.select_school_department = SCHOOLDEPARTMENT[this.user_school].department;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad UserDetailPage');
  }
  setSelectSchool() {
    let id = this.detail.school;
    this.select_school_department = SCHOOLDEPARTMENT[id].department;
  }
  commit() {
    if (this.detail.id != '' &&
      this.detail.name != '' &&
      this.detail.gender != '' &&
      this.detail.school != undefined &&
      this.detail.department != '') {
      let param = {
        action: 'commit',
        account: this.info.account,
        identity: this.info.identity,
        detail: this.detail
      };
      this.bool_send = true;
      this.http_service.http_post('edit_detail', param)
        .then((data) => {
          if (data.answer == true) {
            this.toastCtrl.create({
              message: '修改成功！',
              duration: 3000
            }).present();
            let login_config = {
              is_login: true,
              user_info: {
                account: this.info.account,
                name: this.detail.name,
                identity: this.info.identity,
                school: this.detail.school,
                department: this.detail.department
              }
            };
            this.storage.set('Login', login_config);
            this.navCtrl.pop();
            this.bool_send = false;
          } else {
            this.bool_send = true;
            this.toastCtrl.create({
              message: '修改失败！',
              duration: 2000
            }).present();
            this.bool_send = false;
          }
        });
    }
  }
  edit_password() {
    let param = {
      action: 'edit_password',
      account: this.info.account,
      identity: this.info.identity,
      password_old: this.password_old,
      password_new: this.password_new
    };
    this.bool_send = true;
    this.http_service.http_post('edit_detail', param)
      .then((data) => {
        if (data.answer == true) {
          this.toastCtrl.create({
            message: '修改成功！',
            duration: 3000
          }).present();
          this.navCtrl.pop();
          this.bool_send = false;
        } else {
          this.toastCtrl.create({
            message: '修改失败！',
            duration: 2000
          }).present();
          this.bool_send = false;
        }
      });
  }
}
