import { Component, ViewChild } from '@angular/core';
import { AlertController, IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { HttpServiceProvider } from "../../providers/http-service/http-service";
import {LocalStorageProvider} from "../../providers/local-storage/local-storage";

import { Class } from "../../shared/Class";

/**
 * Generated class for the AddClassPage page.
 *`
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-class',
  templateUrl: 'add-class.html',
})
export class AddClassPage {
  @ViewChild('add_class_slides') add_class_slides: any;
  classes: Class[] = [];
  t_name: string = '';
  c_name: string = '';
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private http_service: HttpServiceProvider,
              private toastCtrl: ToastController,
              private alertCtrl: AlertController,
              private storage: LocalStorageProvider) {
  }

  ionViewDidLoad() {
    this.add_class_slides.lockSwipes(true);
    console.log('ionViewDidLoad AddClassPage');
  }
  search_t() {
    let param = {
      action: 'teacher',
      s_account: this.storage.get('Login', {}).user_info.account,
      t_name: this.t_name
    };
    this.http_service.http_post('add_course', param)
      .then((data) => {
        this.classes = data;
        this.add_class_slides.lockSwipes(false);
        this.add_class_slides.slideNext();
        this.add_class_slides.lockSwipes(true);
      });
  }
  search_c() {
    let param = {
      action: 'course',
      s_account: this.storage.get('Login', {}).user_info.account,
      c_name: this.c_name
    };
    this.http_service.http_post('add_course', param)
      .then((data) => {
        this.classes = data;
        this.add_class_slides.lockSwipes(false);
        this.add_class_slides.slideNext();
        this.add_class_slides.lockSwipes(true);
      });
  }
  select_course(c) {
    if (c[0] != 0) return ;
    this.alertCtrl.create({
      message: '要申请添加这门课程吗？',
      buttons: [
        {
          text: '确定',
          handler: () => {
            let param = {
              action: 'apply',
              s_account: this.storage.get('Login', {}).user_info.account,
              c_id: c.c_id,
              t_account: c.t_account
            };
            this.http_service.http_post('add_course', param)
              .then((data) => {
                if (data.answer == true) {
                  this.toastCtrl.create({
                    message: '申请成功！',
                    duration: 2000
                  }).present();
                  c[0] = 1;
                } else {
                  this.toastCtrl.create({
                    message: '申请失败！',
                    duration: 2000
                  }).present();
                }
              });
          }
        },
        {
          text: '取消'
        }
      ]
    }).present();
  }
}
