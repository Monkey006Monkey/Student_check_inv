import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ImportClassPage } from './import-class';

@NgModule({
  declarations: [
    ImportClassPage,
  ],
  imports: [
    IonicPageModule.forChild(ImportClassPage),
  ],
})
export class ImportClassPageModule {}
