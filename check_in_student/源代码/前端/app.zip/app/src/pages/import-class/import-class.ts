import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { HttpServiceProvider } from "../../providers/http-service/http-service";
import { LocalStorageProvider } from "../../providers/local-storage/local-storage";

import { Class } from "../../shared/Class";

import { LOCATION } from "../../shared/mock.location";

/**
 * Generated class for the ImportClassPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-import-class',
  templateUrl: 'import-class.html',
})
export class ImportClassPage {
  bool_send: boolean;
  new_class: Class = {
    c_id: '',
    c_name: '',
    c_date: undefined,
    c_start_week: undefined,
    c_end_week: undefined,
    c_location: '',
    c_time: '',
    t_account: '',
    t_name: '',
    c_students: 0,
    c_rows: undefined,
    c_columns: undefined
  };
  week = [];
  weeks = [];
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private http_service: HttpServiceProvider,
              private toastCtrl: ToastController,
              private storage: LocalStorageProvider) {
    this.bool_send = false;
    for (let i = 1; i <= 7; i++) {
      this.week.push(i);
    }
    for (let i = 1; i <= 18; i++) {
      this.weeks.push(i);
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ImportClassPage');
  }
  commit() {
    if (this.new_class.c_name != '' &&
        this.new_class.c_date != undefined &&
        this.new_class.c_start_week != undefined &&
        this.new_class.c_end_week != undefined &&
        this.new_class.c_location != '' &&
        this.new_class.c_time != '') {
      this.new_class.c_location = this.new_class.c_location.replace(/ /g, '');
      this.new_class.c_location = this.new_class.c_location.replace(/-/g, '—');
      LOCATION.forEach((value) => {
        if (value.name == this.new_class.c_location) {
          this.new_class.c_rows = value.row;
          this.new_class.c_columns = value.col;
        }
      });
      if (this.new_class.c_end_week < this.new_class.c_start_week) {
        this.toastCtrl.create({
          message: '结束周早于开始周',
          duration: 2000
        }).present();
      } else if (this.new_class.c_rows == undefined || this.new_class.c_columns == undefined) {
        this.toastCtrl.create({
          message: '找不到该教室',
          duration: 2000
        }).present();
      } else {
        this.new_class.t_account = this.storage.get('Login', {}).user_info.account;
        this.new_class.t_name = this.storage.get('Login', {}).user_info.name;
        this.bool_send = true;
        this.http_service.http_post('import_course', this.new_class)
          .then((data) => {
            if (data.answer == true) {
              this.toastCtrl.create({
                message: '课程添加成功！',
                duration: 3000
              }).present();
              this.bool_send = false;
            } else {
              this.toastCtrl.create({
                message: '课程已存在！',
                duration: 2000
              }).present();
              this.bool_send = false;
            }
          });
      }
    } else {
      this.toastCtrl.create({
        message: '输入信息不完整',
        duration: 2000
      }).present();
    }
  }
}
