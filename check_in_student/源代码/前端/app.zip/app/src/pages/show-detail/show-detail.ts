import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { SchoolDepartment } from "../../shared/SchoolDepartment";
import { SCHOOLDEPARTMENT } from "../../shared/mock.school";

/**
 * Generated class for the ShowDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-show-detail',
  templateUrl: 'show-detail.html',
})
export class ShowDetailPage {
  s_info: any;
  school_department: SchoolDepartment[] = SCHOOLDEPARTMENT;
  constructor(public navCtrl: NavController,
              public navParams: NavParams) {
    this.s_info = this.navParams.get('s_info');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ShowDetailPage');
  }
}
