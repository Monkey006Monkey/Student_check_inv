import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ShowDetailPage } from './show-detail';

@NgModule({
  declarations: [
    ShowDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(ShowDetailPage),
  ],
})
export class ShowDetailPageModule {}
