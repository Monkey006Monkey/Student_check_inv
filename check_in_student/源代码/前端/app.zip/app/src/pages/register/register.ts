import { Component, ViewChild } from '@angular/core';
import { ToastController, IonicPage, NavController, NavParams, Events } from 'ionic-angular';

import { AuthenticationCodeProvider } from "../../providers/authentication-code/authentication-code";
import { HttpServiceProvider } from "../../providers/http-service/http-service";

import { StudentDetail } from "../../shared/StudentDetail";
import { TeacherDetail } from "../../shared/TeacherDetail";
import { SchoolDepartment } from "../../shared/SchoolDepartment";

import { SCHOOLDEPARTMENT } from "../../shared/mock.school";

import { SMS } from "@ionic-native/sms";

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  @ViewChild('register_slides') register_slides: any;
  register_info = {
    account: '',
    password: '',
    identity: ''
  };
  student_detail: StudentDetail = {
    account: '',
    password: '',
    identity: '',
    id: '',
    name: '',
    gender: '',
    school: undefined,
    department: '请先选择学校',
    photo: ''
  };
  teacher_detail: TeacherDetail = {
    account: '',
    password: '',
    identity: '',
    id: '',
    name: '',
    gender: '',
    school: undefined,
    department: '请先选择学校',
    professional_title: '',
    photo: ''
  };
  code: string;
  input_code: string;
  flag_code: number;
  flag_button = [
    '关闭验证码（多账号调试用）',
    '启用验证码'
  ];
  school_department: SchoolDepartment[] = SCHOOLDEPARTMENT;
  select_school_department: string[];
  selectOptions: any;
  toast: any;
  num: number;
  text_send: string;
  bool_send: boolean;
  clock: any;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private toastCtrl: ToastController,
              private events: Events,
              private authenticationCodeService: AuthenticationCodeProvider,
              private http_service: HttpServiceProvider,
              private sms: SMS) {
    this.flag_code = 0;
    this.code = 'qwerty';
    this.text_send = '获取验证码';
    this.select_school_department = ['请先选择学校'];
    this.selectOptions = {
      title: '选择您的身份',
      mode: 'md'
    };
    this.toast = this.toastCtrl.create({
      message: '请将信息填写完整',
      duration: 2000
    })
  }

  ionViewDidLoad() {
    this.register_slides.lockSwipes(true);
  }
  setSelectSchool() {
    let id;
    if (this.register_info.identity=='学生') {
      id = this.student_detail.school;
    }
    else {
      id = this.teacher_detail.school;
    }
    this.select_school_department = this.school_department[id].department;
  }
  next() {
    if (this.register_info.account!='' && this.register_info.password!='' && this.register_info.identity!='') {
      this.register_slides.lockSwipes(false);
      this.register_slides.slideNext();
      this.register_slides.lockSwipes(true);
    } else {
      this.toast.present();
    }
  }
  get_code() {
    this.code = this.authenticationCodeService.createCode(6);
    console.log(this.code);
    this.sms.send(this.register_info.account, this.code)
      .then(() => {
      });
    this.num = 60;
    this.text_send = this.num + '秒后可重新获取';
    this.bool_send = true;
    this.clock = setInterval(() => {
      this.num--;
      if (this.num > 0) {
        this.text_send = this.num + '秒后可重新获取';
      } else {
        this.text_send = '重新发送验证码';
        this.bool_send = false;
        clearInterval(this.clock);
      }
    }, 1000);
  }
  next_code() {
    if (this.flag_code == 1) {
      this.register_slides.lockSwipes(false);
      this.register_slides.slideNext();
      this.register_slides.lockSwipes(true);
    } else if (this.authenticationCodeService.validate(this.input_code)) {
      this.register_slides.lockSwipes(false);
      this.register_slides.slideNext();
      this.register_slides.lockSwipes(true);
    } else {
      this.toastCtrl.create({
        message: '验证码不正确或已过期！',
        duration: 2000
      }).present();
    }
  }
  able_code() {
    this.flag_code = this.flag_code ^ 1;
  }
  previous() {
    this.register_slides.lockSwipes(false);
    this.register_slides.slidePrev();
    this.register_slides.lockSwipes(true);
  }
  completeRegister() {
    if (this.register_info.identity=='学生') {
      if (this.student_detail.id!='' &&
          this.student_detail.name!='' &&
          this.student_detail.gender!='' &&
          this.student_detail.school!=undefined &&
          this.student_detail.department!='') {
        this.student_detail.account = this.register_info.account;
        this.student_detail.password = this.register_info.password;
        this.student_detail.identity = this.register_info.identity;
        this.register(this.student_detail);
      } else {
        this.toast.present();
      }
    } else if(this.register_info.identity=='教师'){
      if (this.teacher_detail.id!='' &&
          this.teacher_detail.name!='' &&
          this.teacher_detail.gender!='' &&
          this.teacher_detail.school!=undefined &&
          this.teacher_detail.department!='' &&
          this.teacher_detail.professional_title!='') {
        this.teacher_detail.account = this.register_info.account;
        this.teacher_detail.password = this.register_info.password;
        this.teacher_detail.identity = this.register_info.identity;
        this.register(this.teacher_detail);
      } else {
        this.toast.present();
      }
    }
  }
  register(params: any) {
    this.http_service.http_post('register', params)
      .then((data) => {
        if (data.answer == true) {
          this.events.publish('Login', data.detail);
          this.toastCtrl.create({
            message: '注册成功！',
            duration: 3000
          }).present();
        } else {
          this.toastCtrl.create({
            message: '注册失败！用户名已存在',
            duration: 3000
          }).present();
        }
      });
  }
}
