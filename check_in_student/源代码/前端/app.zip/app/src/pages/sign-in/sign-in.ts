import { Component } from '@angular/core';
import {AlertController, IonicPage, NavController, NavParams} from 'ionic-angular';

import { HttpServiceProvider } from "../../providers/http-service/http-service";
import { LocalStorageProvider } from "../../providers/local-storage/local-storage";

import { Seat } from "../../shared/Seat";


/**
 * Generated class for the SginInPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-sign-in',
  templateUrl: 'sign-in.html',
})
export class SignInPage {
  bool_send: boolean;
  course: any;
  show: number;
  seat: Seat = {
    row: undefined,
    col: undefined,
    detail: []
  };
  select_seat = {
    row: 1,
    col: 1
  };
  row = [];
  col = [];
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private http_service: HttpServiceProvider,
              private alertCtrl: AlertController,
              private storage: LocalStorageProvider) {
    this.bool_send = false;
    this.show = -1;
    this.course = this.navParams.get('course');
    console.log(this.course);
    for (let i = 1; i <= this.course.c_rows; i++) {
      this.row.push(i);
    }
    for (let i = 1; i <= this.course.c_columns; i++) {
      this.col.push(i);
    }
    let param = {
      action: 'check',
      c_id: this.course.c_id
    };
    this.http_service.http_post('sign_in', param)
      .then((data) => {
        if (data.answer == false) {
          this.show = 0;
        } else {
          let p2 = {
            action: 'check_sign',
            c_id: this.course.c_id,
            s_account: this.storage.get('Login', {}).user_info.account
          };
          this.http_service.http_post('sign_in', p2)
            .then((data) => {
              if (data.answer == false) {
                this.show = 2;
              } else {
                this.show = 1;
              }
            });
        }
      });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignInPage');
  }
  sign_in() {
    let param = {
      action: 'sign_in',
      c_id: this.course.c_id,
      position: (this.select_seat.row - 1) * this.course.c_columns + this.select_seat.col * 1,
      s_account: this.storage.get('Login', {}).user_info.account
    };
    console.log(param.position);
    this.bool_send = true;
    this.http_service.http_post('sign_in', param)
      .then((data) => {
        if (data.answer == true) {
          this.alertCtrl.create({
            message: '签到成功！',
            buttons: ['确定']
          }).present();
          this.bool_send = false;
          this.show = 2;
        } else {
          this.alertCtrl.create({
            title: '该位置不可用！',
            message: '该位置已被其他人签到，请确认您现在所在的位置！',
            buttons: ['确定']
          }).present();
          this.bool_send = false;
        }
      });
  }
}
