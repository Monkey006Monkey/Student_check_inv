import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, AlertController } from 'ionic-angular';

import { HttpServiceProvider } from "../../providers/http-service/http-service";
import { LocalStorageProvider } from "../../providers/local-storage/local-storage";

import { SchoolDepartment } from "../../shared/SchoolDepartment";

import { SCHOOLDEPARTMENT } from "../../shared/mock.school";


/**
 * Generated class for the VerifyPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-verify',
  templateUrl: 'verify.html',
})
export class VerifyPage {
  t_account: string;
  show: number;
  verify_info: any[] = [];
  school_department: SchoolDepartment[] = SCHOOLDEPARTMENT;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private storage: LocalStorageProvider,
              private http_service: HttpServiceProvider,
              private toastCtrl: ToastController,
              private alertCtrl: AlertController) {
    this.show = -1;
    this.t_account = this.storage.get('Login', {}).user_info.account;
    let param = {
      action: 'get',
      t_account: this.t_account
    };
    this.http_service.http_post('verify', param)
      .then((data) => {
        this.verify_info = data;
        if (data.length == 0) {
          this.show = 0;
        } else {
          this.show = 1;
        }
      });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad VerifyPage');
  }
  confirm(c) {
    this.alertCtrl.create({
      message: '要同意该申请吗？',
      buttons: [
        {
          text: '同意申请',
          handler: () => {
            let param = {
              action: 'confirm',
              s_account: c[0].account,
              s_name: c[0].name_,
              s_gender: c[0].gender,
              s_school: c[0].school,
              s_department: c[0].department,
              t_account: this.t_account,
              t_name: c[1].t_name,
              c_id: c[1].c_id,
              c_name: c[1].c_name,
              c_start_week: c[1].c_start_week,
              c_end_week: c[1].c_end_week,
              c_date: c[1].c_date,
              c_time: c[1].c_time,
              c_location: c[1].c_location,
              c_rows: c[1].c_rows,
              c_columns: c[1].c_columns,
              sign_count: 0
            };
            this.http_service.http_post('verify', param)
              .then((data) => {
                if (data.answer == true) {
                  this.toastCtrl.create({
                    message: '审核成功！',
                    duration: 2000
                  }).present();
                  this.verify_info.splice(this.verify_info.indexOf(c), 1);
                } else {
                  this.toastCtrl.create({
                    message: '审核失败！',
                    duration: 3000
                  }).present();
                }
              });
          }
        },
        {
          text: '拒绝申请',
          handler: () => {
            let param = {
              action: 'refuse',
              s_account: c[0].account,
              c_id: c[1].c_id
            };
            this.http_service.http_post('verify', param)
              .then((data) => {
                if (data.answer == true) {
                  this.toastCtrl.create({
                    message: '拒绝成功！',
                    duration: 2000
                  }).present();
                  this.verify_info.splice(this.verify_info.indexOf(c), 1);
                } else {
                  this.toastCtrl.create({
                    message: '拒绝失败！',
                    duration: 3000
                  }).present();
                }
              });
          }
        },
        {
          text: '取消'
        }
      ]
    }).present();
  }
}
