import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { SelectClassPage } from "../select-class/select-class";
import { AddClassPage } from "../add-class/add-class";
import { HistoryPage } from "../history/history";
import { ImportClassPage } from "../import-class/import-class";

import { LocalStorageProvider } from "../../providers/local-storage/local-storage";
import {VerifyPage} from "../verify/verify";

/**
 * Generated class for the StudentHomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {
  identity: string;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private storage: LocalStorageProvider) {
    this.identity = this.storage.get('Login', {}).user_info.identity;
  }

  ionViewDidLoad() {
  }
  toSelectClassPage(type: string) {
    this.navCtrl.push(SelectClassPage, {'type': type});
  }
  toAddClassPage() {
    this.navCtrl.push(AddClassPage);
  }
  toHistoryPage() {
    this.navCtrl.push(HistoryPage);
  }
  toImportClassPage() {
    this.navCtrl.push(ImportClassPage);
  }
  toVerify() {
    this.navCtrl.push(VerifyPage);
  }
}
