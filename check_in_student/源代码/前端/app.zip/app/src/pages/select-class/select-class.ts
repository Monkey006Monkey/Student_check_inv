import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { SignInPage } from "../sign-in/sign-in";
import { TeacherCheckPage } from "../teacher-check/teacher-check";
import { TeacherHistoryPage } from "../teacher-history/teacher-history";

import { HttpServiceProvider } from "../../providers/http-service/http-service";
import { LocalStorageProvider } from "../../providers/local-storage/local-storage";

/**
 * Generated class for the SelectClassPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-select-class',
  templateUrl: 'select-class.html',
})
export class SelectClassPage {
  classes: any[] = [];
  type: string;
  account: string;
  show: number;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private http_service: HttpServiceProvider,
              private storage: LocalStorageProvider) {
    this.account = this.storage.get('Login',{}).user_info.account;
    this.type = this.navParams.get('type');
    let param = {
      action: this.type,
      s_account: this.account,
      t_account: this.account
    };
    this.http_service.http_post('select_course', param)
      .then((data) => {
        this.classes = data;
        if (data.length == 0) {
          this.show = 0;
        } else {
          this.show = 1;
        }
      });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SelectClassPage');
  }
  select_c(c) {
    if (this.type == 'student_sign_in') {
      this.navCtrl.push(SignInPage, {'course': c});
    } else if (this.type == 'teacher_check') {
      this.navCtrl.push(TeacherCheckPage, {'course': c});
    } else if (this.type == 'teacher_history') {
      this.navCtrl.push(TeacherHistoryPage, {'course': c});
    }
  }
}
