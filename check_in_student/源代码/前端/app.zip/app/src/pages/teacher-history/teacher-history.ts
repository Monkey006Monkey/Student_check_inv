import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Class } from "../../shared/Class";
import { HttpServiceProvider } from "../../providers/http-service/http-service";

import { SchoolDepartment } from "../../shared/SchoolDepartment";
import { SCHOOLDEPARTMENT } from "../../shared/mock.school";
import {SelectCourseInfo} from "../../shared/SelectCourseInfo";

/**
 * Generated class for the TeacherHistoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-teacher-history',
  templateUrl: 'teacher-history.html',
})
export class TeacherHistoryPage {
  course: Class;
  show: number;
  sign_info: SelectCourseInfo[] = [];
  school_department: SchoolDepartment[] = SCHOOLDEPARTMENT;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private http_service: HttpServiceProvider) {
    this.show = -1;
    this.course = this.navParams.get('course');
    let param = {
      action: 'teacher',
      c_id: this.course.c_id,
    };
    this.http_service.http_post('history', param)
      .then((data) => {
        this.sign_info = data;
        if (data.lenght == 0) {
          this.show = 0;
        } else {
          this.show = 1;
        }
      });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TeacherHistoryPage');
  }
}
