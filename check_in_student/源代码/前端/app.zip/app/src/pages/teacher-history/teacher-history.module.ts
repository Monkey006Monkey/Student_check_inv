import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TeacherHistoryPage } from './teacher-history';

@NgModule({
  declarations: [
    TeacherHistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(TeacherHistoryPage),
  ],
})
export class TeacherHistoryPageModule {}
