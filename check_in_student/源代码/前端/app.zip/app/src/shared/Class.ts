export class Class {
  c_id: string;
  c_name: string;
  c_date: number;
  c_start_week: number;
  c_end_week: number;
  c_location: string;
  c_time: string;
  t_account: string;
  t_name: string;
  c_students: number;
  c_rows: number;
  c_columns: number;
}
