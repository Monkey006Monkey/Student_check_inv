export class TeacherDetail {
  account: string;
  password: string;
  identity: string;
  id: string;
  name: string;
  gender: string;
  school: number;
  department: string;
  professional_title: string;
  photo: string;
}
