export class Location {
  id: number;
  name: string;
  row: number;
  col: number;
}
