import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, Events } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { LoginPage } from "../pages/login/login";
import { UserDetailPage } from "../pages/user-detail/user-detail";
import { HomePage } from "../pages/home/home";
import { WelcomePage } from "../pages/welcome/welcome";

import { LocalStorageProvider } from "../providers/local-storage/local-storage";

import { SchoolDepartment } from "../shared/SchoolDepartment";

import { SCHOOLDEPARTMENT } from "../shared/mock.school";

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
  rootPage: any = LoginPage;
  login_config: {
    is_login: boolean,
    user_info: {
      account: string,
      name: string,
      identity: string,
      school: number,
      department: string,
      professional_title: string
    }
  };
  is_run: {
    flag: boolean
  };
  school_department: SchoolDepartment[];
  constructor(public platform: Platform,
              public statusBar: StatusBar,
              public splashScreen: SplashScreen,
              private storage: LocalStorageProvider,
              private events: Events) {
    this.initializeApp();
    this.is_run = this.storage.get('IsRun', {
      flag: false
    });
    this.school_department = SCHOOLDEPARTMENT;
    this.login_config = this.storage.get('Login',{
      is_login: false,
      user_info: {
        account: '',
        name: '',
        identity: '',
        school: 0,
        department: '',
        professional_title: ''
      }
    });
    if (this.is_run.flag == false) {
      this.is_run.flag = true;
      this.rootPage = WelcomePage;
      this.storage.set('IsRun', this.is_run);
    } else if (this.login_config.is_login==true) {
      this.rootPage = HomePage;
    } else {
      this.rootPage = LoginPage;
    }
    this.events.subscribe('Login',(data) => {
      this.login_config.is_login = true;
      this.login_config.user_info = data;
      this.storage.set('Login', this.login_config);
      this.nav.setRoot(HomePage);
    });
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  toSetting() {
    //this.nav.push(SettingPage);
  }
  toUserDetail() {
    this.nav.push(UserDetailPage, {type: 'detail'});
  }
  toEditPassword() {
    this.nav.push(UserDetailPage, {type: 'password'});
  }
  logout() {
    this.storage.remove('Login');
    this.nav.setRoot(LoginPage);
  }
}
