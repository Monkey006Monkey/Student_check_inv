import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from "../pages/home/home";
import { LoginPage } from "../pages/login/login";
import { UserDetailPage } from "../pages/user-detail/user-detail";
import { SignInPage } from "../pages/sign-in/sign-in";
import { RegisterPage } from "../pages/register/register";
import { SelectClassPage } from "../pages/select-class/select-class";
import { AddClassPage } from "../pages/add-class/add-class";
import { ImportClassPage } from "../pages/import-class/import-class";
import { HistoryPage } from "../pages/history/history";
import { TeacherCheckPage } from "../pages/teacher-check/teacher-check";
import { TeacherHistoryPage } from "../pages/teacher-history/teacher-history";
import { VerifyPage } from "../pages/verify/verify";
import { WelcomePage } from "../pages/welcome/welcome";
import { ShowDetailPage } from "../pages/show-detail/show-detail";
//import { AskForLeavePage } from "../pages/ask-for-leave/ask-for-leave";

import { LocalStorageProvider } from "../providers/local-storage/local-storage";

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HttpClientModule } from "@angular/common/http";
import { JsonpModule } from "@angular/http";
import { HttpServiceProvider } from '../providers/http-service/http-service';
import { AuthenticationCodeProvider } from '../providers/authentication-code/authentication-code';

import { SMS } from "@ionic-native/sms";

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    UserDetailPage,
    SignInPage,
    RegisterPage,
    AddClassPage,
    SelectClassPage,
    ImportClassPage,
    HistoryPage,
    TeacherCheckPage,
    TeacherHistoryPage,
    VerifyPage,
    WelcomePage,
    ShowDetailPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    JsonpModule,
    IonicModule.forRoot(MyApp,{
      backButtonText: '', // 配置返回按钮的文字
      // backButtonIcon: 'arrow-dropleft-circle' // 配置返回按钮的图标
    }),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    UserDetailPage,
    SignInPage,
    RegisterPage,
    AddClassPage,
    SelectClassPage,
    ImportClassPage,
    HistoryPage,
    TeacherCheckPage,
    TeacherHistoryPage,
    VerifyPage,
    WelcomePage,
    ShowDetailPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    LocalStorageProvider,
    HttpServiceProvider,
    AuthenticationCodeProvider,
    SMS
  ]
})
export class AppModule {}
